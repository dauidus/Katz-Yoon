var ameTestConfig = {
	siteUrl: 'http://localhost/ame-tests',
	adminUrl: 'http://localhost/ame-tests/wp-admin',
	adminUsername: 'admin',
	adminPassword: 'password'
};